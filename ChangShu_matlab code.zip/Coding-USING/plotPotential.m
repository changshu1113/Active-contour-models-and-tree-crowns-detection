function plotPotential(parameters)

x = [-2:0.1:2];

x2 = x.*x;

x3 = x.*x2;

x4 = x.*x3;

y = parameters.lambda*(0.25*x4 - 0.5*x2 + 0.25) + parameters.alpha*(x - (1/3)*x3 + (2/3));

figure;

plot(x, y);
