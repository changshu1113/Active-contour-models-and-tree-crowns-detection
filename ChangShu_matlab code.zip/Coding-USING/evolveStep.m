function funcDer = evolveStep(oldPhi, linearOp, parameters,Imageop)

% Note that the Phi variables are in Fourier space.
% linearPart is (a multiple of) the Fourier transform of Laplacian, passed in to make things quicker.
% The zero of Fourier space is at (need to check how FFT works in scilab).



%Linear factor

hatOldPhi = fftshift(fft2(oldPhi));

opOldPhi = linearOp.*hatOldPhi;

linearPart = real(ifft2(ifftshift(opOldPhi)));

% Compute the nonlinear contribution, which can be zero.

nonlinearPart = computeNonlinearPart(oldPhi, parameters.lambda, parameters.alpha);

funcDer = linearPart + parameters.alpha +nonlinearPart+Imageop;