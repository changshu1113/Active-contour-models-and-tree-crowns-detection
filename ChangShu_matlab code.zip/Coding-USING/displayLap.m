function L = displayLap(alpha)

L = fspecial('laplacian', alpha);

bL = padarray(L, [29, 29]);

imPlot(bL);

fL = fftshift(fft2(bL));

imPlot(abs(fL));