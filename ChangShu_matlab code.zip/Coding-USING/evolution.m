function newPhi = evolution(initPhi, tolerance, maxIts, parameters, showFreq)
I=loadimage;
W = parameters.W;
% sigmaIn2=0.14^2;
%  sigmaOut2=0.07^2;
%   muIn=0.41;
%  muOut=0.66;
sigmaIn2=180;
 sigmaOut2=350;
  muIn=mean2(I)-50;
 muOut=mean2(I)+50;
%  muIn=mean2(I)-40;
%  muOut=mean2(I)+40;
 Imageop=W .* ((1/(2*(sigmaIn2))).* (I-muIn).^2-(1/(2*(sigmaOut2))) .* (I-muOut).^2);

imPlot(-Imageop);title('Image operator');
figure; imagesc(-Imageop); colorbar; title('Image operator');
 

linearOp = computeLinearPart(initPhi, parameters);

oldPhi = initPhi; %oldPhi = phi;

converged = 0;

numIts = 0;

deltaPhi = 0;

newPhi = [];

meanFuncDer = 0;
meanDeltaPhi = 0;
maxFuncDer = 0;
deltaT = 0;

while (~converged) %while converged =1 

%     if (mod(numIts, showFreq/10) == 0)
%         numIts
%         meanFuncDer
%         maxFuncDer
%         deltaT
%         sum(sum(oldPhi)) / prod(size(oldPhi))
%     end;

    if (mod(numIts, showFreq) == 0) %mod is Remainder after division
%         close all;
        displayPhi(oldPhi);
%         pause;
    end

    funcDer = evolveStep(oldPhi, linearOp, parameters,Imageop);

    maxFuncDer = max(max(abs(funcDer))); % first max is the max of each column
     %deltaT = 1/(3*maxFuncDer);
    deltaT = 1/(10*maxFuncDer);

%     deltaT = 0.05;

    deltaPhi = -deltaT*funcDer;

    newPhi = oldPhi + deltaPhi;

    meanFuncDer = mean2(sqrt((abs(funcDer) .* abs(funcDer)))); %mean of matrix elements
%     meanDeltaPhi = mean2(sqrt((abs(deltaPhi) .* abs(deltaPhi))));

    if ((meanFuncDer < tolerance) | (numIts > maxIts)) %when the derivative is very small or ...
        converged = 1;
        numIts
        meanFuncDer
        tolerance
    end;

    numIts = numIts + 1;

    oldPhi = newPhi;

end;
