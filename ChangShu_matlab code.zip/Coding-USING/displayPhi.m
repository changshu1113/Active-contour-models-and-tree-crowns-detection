function displayPhi(phi)

imPlot(phi);

% R = (phi > 0);
% 
% imPlot(R);
