function linearOp = computeLinearPart(phi, parameters)

D = parameters.D;

lambda = parameters.lambda;

beta = parameters.beta;

discrete = parameters.discrete;

K2 = computeNegLaplacian(size(phi), discrete);

interactionOperator = computeInteractionOperator(K2, parameters);

linearOp = (K2 .* (D - beta*interactionOperator) - lambda);