function interactionOperator = computeInteractionOperator(K2, parameters)

d = parameters.d;
d2 = d^(2);

if(parameters.marie == 0)
   % interactionOperator = 1 ./(1 + d2 * K2); 
  %  interactionOperator = d2 ./(1 + d2 * K2);
     interactionOperator = 1 ./(1 +  K2);

else
    
    N = size(K2);
    
    Nx = N(2);
    
    Ny = N(1);
    
    
    
    epsilon = parameters.epsilon;
    
    
    x = -Nx/2:1:Nx/2 - 1;
    
    y = -Ny/2:1:Ny/2 - 1;
    
    
    [X, Y] = meshgrid(x, y);
    
    R = sqrt(X .* X + Y .* Y);
    
    innerSpaceIntInterOp = (R <= d - epsilon);
    
    centredR = (R - d) / epsilon;
    
    centreSpaceIntInterOp = (1/2) * (1 - centredR - (1/pi) * sin(pi * centredR)) .* (R > d - epsilon) .* (R < d + epsilon);
    
    spaceIntInterOp = innerSpaceIntInterOp + centreSpaceIntInterOp; %like interaction function
    
    %imPlot(spaceIntInterOp);
    %
    %pause;
    
    interactionOperator = fftshift(fft2(ifftshift(spaceIntInterOp))); %fourier tranform
    
    % imPlot(abs(intInterOp));
    %
    % pause;
    
    % imPlot(abs(interactionOperator));
    %
    % pause;
    %
    % imPlot(real(fftshift(ifft2(ifftshift(interactionOperator)))));
    %
    % pause;
    
end;