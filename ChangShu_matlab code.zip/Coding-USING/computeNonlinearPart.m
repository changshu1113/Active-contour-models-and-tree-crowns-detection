function nonlinearPart = computeNonlinearPart(phi, lambda, alpha)


phi2 = phi.*phi;

phi3 = phi.*phi2;

nonlinearPart = lambda*phi3 - alpha*phi2;
