function phi = initPhi(parameters)

maxPot = parameters.alpha/parameters.lambda; %maximum of the potential V

I=loadimage();
pixle=size(I);
Nx = pixle(2);
Ny =pixle(1);
% Nx = 612;
% Ny =408
%   
%  Ny = 256;
%   Nx = 256;
%   
%  Ny = 256;

 %Nx = 64; %set the number of pixles
 
 %Ny = 64;


%d = 15;

phi = 0.0001*randn(Ny, Nx) + maxPot;

% phi = ones(Nx, Ny);
% 
% x = -Nx/2:1:Nx/2 - 1;
% 
% y = -Ny/2:1:Ny/2 - 1;
% 
% 
% [X, Y] = meshgrid(x, y);
% 
% R = sqrt(X .* X + Y .* Y);
% 
% phi = 2 * (R <= d) - 1; %phi=1 when R <= d else phi=-1
