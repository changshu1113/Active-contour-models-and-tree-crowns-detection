function K2 = computeNegLaplacian(N, discrete)  %   N = size(K2);

Ny = N(1);

Nx = N(2);


kx = -pi:(2*pi/Nx):pi*(Nx - 1)/Nx;

ky = -pi:(2*pi/Ny):pi*(Ny - 1)/Ny;


[Kx, Ky] = meshgrid(kx, ky);

K2d = 2*(1 - cos(Kx) + 1 - cos(Ky)); %this is not used

if (discrete)
    
    Kx = 2 * sin(Kx / 2);
    
    Ky = 2 * sin(Ky / 2);
    
end;

K2 = Kx .* Kx + Ky .* Ky;

% imPlot(K2d);
% 
% title('Discrete Laplacian');
% 
% imPlot(K2c);
% 
% title('Continuous Laplacian');

Lc = real(fftshift(ifft2(ifftshift(1 ./(K2 + 0.5)))));

imPlot(Lc);

title('Spatial continuous Lap');

Ld = real(fftshift(ifft2(ifftshift(1 ./ (K2 + 0.5)))));

imPlot(Ld);

title('Spatial discrete Lap');

% pause;
