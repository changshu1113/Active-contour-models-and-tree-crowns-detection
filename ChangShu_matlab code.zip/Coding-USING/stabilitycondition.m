function S = stabilitycondition(parameters)

D = parameters.D;

lambda = parameters.lambda;

alpha = parameters.alpha;

beta = parameters.beta;

Splus = (sqrt(D) + sqrt(2*(lambda + alpha)))^(2);

Sminus = (sqrt(D) + sqrt(2*(lambda - alpha)))^(2);

if ((beta > Splus) || (beta > Sminus))
    S = 'Turing instability';
else
    S = 'No Turing instablity'; %beta<Sminus
end
    
   