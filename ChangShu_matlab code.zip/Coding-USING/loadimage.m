function I=loadimage()
Icolour=imread('tree3.png'); %add image
Igray=rgb2gray(Icolour); %Convert RGB image or colormap to grayscale
I=double(Igray);%scale value% double precision
%I=rescale(I_beforescale);%scale value
