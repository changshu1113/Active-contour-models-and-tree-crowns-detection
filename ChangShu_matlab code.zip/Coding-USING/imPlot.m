function imPlot(phi) %image plot, plot initial phi and final phi

fig = gcf;

figure(fig);

imagesc(phi);

colormap('parula');
%colormap('jet');

colorbar;
