function finalPhi = mainPhase()


close all; 
%parameters = struct('W',1, 'D', 0.00001, 'lambda',0.00001, 'alpha',0.00001 , 'beta', 0.00001, 'd', 9, 'epsilon', 9, 'discrete', 0, 'marie', 0);%no prior
%parameters = struct('W',2, 'D', 28, 'lambda', 25, 'alpha',25 , 'beta', 0, 'd', 9, 'epsilon', 9, 'discrete', 0, 'marie', 0);% classical prior 

%parameters = struct('W',2, 'D', 28, 'lambda', 25, 'alpha',25 , 'beta', 20, 'd', 9, 'epsilon', 9, 'discrete', 0, 'marie', 0);
%parameters = struct('W',0,'D', 1, 'lambda', 1, 'alpha', 0.6, 'beta', 3, 'd', 3, 'epsilon', 3, 'discrete', 0, 'marie', 0);%original one

%parameters = struct('D', 1, 'lambda', 100, 'alpha', 25, 'beta', 30, 'd', 8, 'epsilon', 9, 'discrete', 0, 'marie', 0);

% parameters = struct('D', 1, 'lambda', 1, 'alpha', 0, 'beta', 3, 'd', 3, 'epsilon', 1, 'discrete', 1, 'marie', 1);
%parameters = struct('W', 3, 'D', 28, 'lambda', 25, 'alpha', 25, 'beta', 20, 'd', 5, 'epsilon', 3, 'discrete', 0, 'marie', 0);
parameters = struct('W',2, 'D', 28, 'lambda', 25, 'alpha',25 , 'beta', 20, 'd', 9, 'epsilon', 9, 'discrete', 0, 'marie', 0);%good result 
%parameters = struct('W',2, 'D', 80, 'lambda', 25, 'alpha',25 , 'beta', 20, 'd', 9, 'epsilon', 9, 'discrete', 0, 'marie', 1);
%parameters = struct('W',0, 'D', 2, 'lambda', 2, 'alpha',0.5 , 'beta', 0.6, 'd', 9, 'epsilon', 9, 'discrete', 1, 'marie', 1);
% parameters = struct('D', 0.1, 'lambda', 0.1, 'alpha', 0.05, 'beta', 0.02, 'd', 3, 'epsilon', 1, 'discrete', 1, 'marie', 0);
S = stabilitycondition(parameters);

S



 phi = initPhi(parameters); %matrix of initial phi Ny*Nx

 %displayPhi(phi); %colorful picture, imPlot(phi) this is figure 1

 %pause

 %plotPotential(parameters); %figure 2, plot potential V

 %pause

 
 tolerance = 0.000005;

 %maxIts = 100000;

 maxIts = 10000;

 %maxIts = 5000;

 showFreq = 10;



finalPhi = evolution(phi, tolerance, maxIts, parameters, showFreq);

displayPhi(finalPhi); %this is the figure 3, use the imPlot function